<?php

use OTGS\Toolset\Types\Filesystem\Directory;

if ( false ) {
	/** @deprecated  */
	class Toolset_Filesystem_Directory extends Directory { }
}

class_exists( Directory::class );
