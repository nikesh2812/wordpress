<?php

/**
 * Interface Types_Field_Setting_Bool_Interface
 *
 * @since 2.3
 */
interface Types_Field_Setting_Bool_Interface {
	/**
	 * @return bool
	 */
	public function is_true();
}