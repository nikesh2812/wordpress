<?php

/**
 * Interface Types_Interface_Url
 *
 * @since 2.3
 */
interface Types_Interface_Url {
	/**
	 * @return string
	 */
	public function get_url();
}