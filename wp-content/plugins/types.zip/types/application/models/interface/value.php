<?php

/**
 * Interface Types_Interface_Value
 *
 * @since 2.3
 */
interface Types_Interface_Value {
	/**
	 * @return string
	 */
	public function get_value();
}